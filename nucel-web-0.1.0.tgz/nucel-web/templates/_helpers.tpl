{{/*
Expand the name of the chart.
*/}}
{{- define "nucel-web.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name. We truncate at 63 chars because some
Kubernetes name fields are limited to this (RFC 1035).
*/}}
{{- define "nucel-web.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Chart name + version label.
*/}}
{{- define "nucel-web.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels — these end up on every object the chart emits.
*/}}
{{- define "nucel-web.labels" -}}
helm.sh/chart: {{ include "nucel-web.chart" . }}
{{ include "nucel-web.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/component: marketing
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Selector labels — kept stable across versions so Deployments can be upgraded
in-place without recreating Services / ReplicaSets. These must match the
labels emitted by the previous `web/k8s/*.yaml` manifests exactly, otherwise
the first `helm upgrade --install` would orphan the running pods.
*/}}
{{- define "nucel-web.selectorLabels" -}}
app.kubernetes.io/name: {{ include "nucel-web.name" . }}
{{- end -}}

{{/*
Name of the Secret that holds STAGING_BASIC_AUTH. If `existingSecret` is set
we point at it, otherwise we render a chart-managed Secret.
*/}}
{{- define "nucel-web.basicAuthSecretName" -}}
{{- if .Values.basicAuth.existingSecret -}}
{{- .Values.basicAuth.existingSecret -}}
{{- else -}}
{{- printf "%s-basic-auth" (include "nucel-web.fullname" .) -}}
{{- end -}}
{{- end -}}
