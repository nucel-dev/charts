# nucel-web Helm chart

Marketing site (SvelteKit) for **nucel** — the workflow layer for AI-native
development. Replaces the hand-rolled manifests that used to live under
`web/k8s/` with an idiomatic chart so day-2 ops (rollbacks, value overrides,
multi-env installs) become trivial.

## Layout

```
charts/nucel-web/
├── Chart.yaml
├── values.yaml
├── README.md
└── templates/
    ├── _helpers.tpl
    ├── deployment.yaml
    ├── ingress.yaml
    ├── secret.yaml       # pre-launch basic-auth gate (gated on values)
    └── service.yaml
```

## Install / upgrade

```sh
# Pre-launch (staging gate ON) — generate a strong password and pass it inline:
PASS="$(openssl rand -base64 24 | tr -d '/+=' | cut -c1-24)"

helm upgrade nucel-web ./charts/nucel-web \
  --install \
  --kube-context=neoconto \
  --namespace nucel-web \
  --create-namespace \
  --set basicAuth.enabled=true \
  --set basicAuth.user=nucel \
  --set basicAuth.password="$PASS" \
  --wait

echo "Staging credential: nucel / $PASS"
```

When you're ready to flip the site public:

```sh
helm upgrade nucel-web ./charts/nucel-web \
  --kube-context=neoconto \
  --namespace nucel-web \
  --reuse-values \
  --set basicAuth.enabled=false \
  --wait
```

## Why the gate lives in the app, not the ingress

The cluster uses `ingressClassName: alb` (AWS Load Balancer Controller).
The familiar `nginx.ingress.kubernetes.io/auth-basic` annotations have no
effect on ALB, so the chart wires the credentials into the SvelteKit
`hooks.server.ts` handler instead. The handler:

* Reads `STAGING_BASIC_AUTH` (format `user:pass`) at request time.
* 401s any request without a matching `Authorization: Basic …` header.
* Whitelists kubelet (`kube-probe/…`) and ALB (`ELB-HealthChecker/…`)
  health probes by `User-Agent` so the deployment stays Ready.
* Is a no-op when the env var is unset (local dev, CI, prerender).

If you ever move the marketing site behind nginx-ingress you can drop the
app-layer gate and reach for the annotations again — toggle
`basicAuth.enabled=false` and add the annotations under `ingress.annotations`.

## Values cheatsheet

| Key                          | Default                  | Notes                                              |
| ---------------------------- | ------------------------ | -------------------------------------------------- |
| `image.repository`           | ECR `nucel-web` repo     | Override per-env if you mirror the image           |
| `image.tag`                  | `0.1.3`                  | Falls back to `.Chart.AppVersion` if unset         |
| `replicaCount`               | `2`                      | Cluster default is two amd64 nodes                 |
| `envFromSecret`              | `nucel-web-env`          | Holds `DATABASE_URL`, `BETTER_AUTH_SECRET`, `ORIGIN` — managed out of band |
| `ingress.host`               | `www.nucel.neoconto.com` | Pre-launch hostname; flip to `www.nucel.dev` for prod |
| `ingress.annotations`        | shared-ALB defaults      | Preserved verbatim from the old manifests          |
| `basicAuth.enabled`          | `true`                   | Staging gate; flip to `false` to go public         |
| `basicAuth.existingSecret`   | _empty_                  | Point at an externally-managed Secret (SealedSecrets, ESO) instead of rendering one |

## Rotating the credential

```sh
helm upgrade nucel-web ./charts/nucel-web \
  --kube-context=neoconto \
  --namespace nucel-web \
  --reuse-values \
  --set basicAuth.password="$(openssl rand -base64 24 | tr -d '/+=' | cut -c1-24)"
```

The chart-managed Secret is updated and pods are restarted to pick it up.

## Verification

```sh
# Without auth → 401
curl -sI https://www.nucel.neoconto.com | head -1

# With auth → 200
curl -sI -u "nucel:$PASS" https://www.nucel.neoconto.com | head -1
```
